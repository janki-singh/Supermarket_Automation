const manager = () => {
    return (
        <div>
            <div style={{marginLeft:"17rem", marginTop:"4rem"}} className="text-center">
                <h1 className="text-6xl">Welcome To</h1>
                <h1 className="text-6xl">Supermarket Automation System</h1>
            </div>
        </div>
    );
}
 
export default manager;