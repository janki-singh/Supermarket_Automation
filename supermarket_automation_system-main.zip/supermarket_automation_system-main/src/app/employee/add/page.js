const manager = () => {
    return (
        <div>
           <div>hehe</div>
        </div>
    );
}
 
export default manager;